"""Chat page — ask questions about the gold tables in natural language.

Uses LLM tool-calling. The LLM can list tables, inspect schemas, and run
SELECT queries through the standalone data layer. Every SQL call is validated
client-side (SELECT-only, allowlisted tables, no DDL/DML). Internal workflow
columns are stripped from every schema and result returned to the model.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

_VISUAL_INTENT = re.compile(
    r"\b(plot|chart|graph|figure|distribution|histogram|box\s*plot|boxplot|"
    r"scatter|bar\s*chart|line\s*chart|visuali[sz]e|trend|frequency)\b",
    re.IGNORECASE,
)
from dotenv import load_dotenv

_DASHBOARD_ROOT = Path(__file__).resolve().parent
load_dotenv(_DASHBOARD_ROOT / ".env", override=True)
if str(_DASHBOARD_ROOT) not in sys.path:
    sys.path.insert(0, str(_DASHBOARD_ROOT))

from gems_auth import require_authorized_user  # noqa: E402
from gems_chat import run_agent  # noqa: E402
from gems_data import GemsData  # noqa: E402
from gems_ui import page_header, sidebar_user  # noqa: E402

st.set_page_config(page_title="Chat · GEMS", layout="wide", page_icon="💬")
page_header(
    "Chat with your data",
    "Ask questions in plain English — the assistant lists tables, reads "
    "schemas, and runs read-only SELECT queries against the GEMS warehouse.",
)

user = require_authorized_user()
sidebar_user(user)

st.sidebar.markdown("**Example questions**")
st.sidebar.caption("- What tables are available and what do they contain?")
st.sidebar.caption("- How many rows are in bodyweight?")
st.sidebar.caption("- Average body weight per contributor, sorted descending.")
st.sidebar.caption("- Which animals have the most respiration-chamber measurements?")
st.sidebar.caption("- Show a bar chart of average body weight by study.")
st.sidebar.caption("- Plot the distribution of methane emissions by species.")

if st.sidebar.button("Clear conversation"):
    st.session_state.pop("chat_history", None)
    st.rerun()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

try:
    data = GemsData()
except Exception as e:
    st.error(f"Data source not configured: {e}")
    st.stop()


def _render_tool_calls(tool_calls: list) -> None:
    if not tool_calls:
        return
    with st.expander("Show query"):
        for i, tc in enumerate(tool_calls, start=1):
            name = tc["name"] if isinstance(tc, dict) else tc.name
            args = tc["arguments"] if isinstance(tc, dict) else tc.arguments
            result = tc["result"] if isinstance(tc, dict) else tc.result

            st.markdown(f"**{i}. `{name}`**")
            if args and "sql" in args:
                st.code(
                    args.get("sql"),
                    language="sql",
                )

            if isinstance(result, dict) and result.get("error"):
                st.error(
                    f"Tool error: {result.get('detail') or result.get('message')}"
                )
            elif isinstance(result, dict) and "rows" in result:
                rows = result.get("rows", [])
                if rows:
                    df = pd.DataFrame(rows)
                    st.caption(
                        f"{result.get('row_count', len(rows))} row(s)"
                        + (" (truncated)" if result.get("truncated") else "")
                    )
                    st.dataframe(df, use_container_width=True)
                else:
                    st.caption("0 rows returned")
            elif isinstance(result, dict) and "tables" in result:
                st.write(result["tables"])
            elif isinstance(result, dict) and "columns" in result and "table" in result:
                st.caption(f"Schema of `{result['table']}`")
                st.dataframe(pd.DataFrame(result["columns"]), use_container_width=True)
            else:
                st.json(result if isinstance(result, dict) else {"value": str(result)})


def _last_aggregate(tool_calls: list) -> dict | None:
    for tc in reversed(tool_calls):
        name = tc["name"] if isinstance(tc, dict) else tc.name
        result = tc["result"] if isinstance(tc, dict) else tc.result
        if name == "run_aggregate_query" and isinstance(result, dict) and result.get("rows"):
            return result
    return None


def _infer_plot_spec(plot_spec: dict | None, last_result: dict, user_text: str = "") -> dict | None:
    if plot_spec:
        return plot_spec
    if not last_result or not last_result.get("rows"):
        return None
    if user_text and not _VISUAL_INTENT.search(user_text):
        return None
    from gems_chat import _auto_chart_spec

    chart_type = "histogram" if re.search(r"\b(histogram|distribution|frequency)\b", user_text, re.I) else "bar"
    return _auto_chart_spec(last_result, chart_type=chart_type)


def _render_plot(plot_spec: dict | None, tool_calls: list, user_text: str = "") -> None:
    last_result = _last_aggregate(tool_calls)
    spec = _infer_plot_spec(plot_spec, last_result or {}, user_text)
    if not spec or not last_result:
        return
    df = pd.DataFrame(last_result["rows"])
    x = spec.get("x")
    y = spec.get("y")
    chart_type = spec.get("chart_type", "bar")
    title = spec.get("title") or None
    if chart_type == "histogram":
        col = x if x in df.columns else y
        if col not in df.columns:
            return
        fig = px.histogram(df, x=col, title=title)
    elif x not in df.columns or y not in df.columns:
        return
    elif chart_type == "line":
        fig = px.line(df, x=x, y=y, title=title)
    elif chart_type == "scatter":
        fig = px.scatter(df, x=x, y=y, title=title)
    elif chart_type == "box":
        fig = px.box(df, x=x, y=y, title=title)
    elif chart_type == "pie":
        fig = px.pie(df, names=x, values=y, title=title)
    else:
        fig = px.bar(df, x=x, y=y, title=title)
    st.plotly_chart(fig, use_container_width=True)


history = st.session_state.chat_history
for idx, turn in enumerate(history):
    with st.chat_message(turn["role"]):
        st.markdown(turn["content"])
        if turn["role"] == "assistant":
            prior_user = ""
            if idx > 0 and history[idx - 1]["role"] == "user":
                prior_user = history[idx - 1].get("content", "")
            _render_plot(turn.get("plot_spec"), turn.get("tool_calls", []), prior_user)
            _render_tool_calls(turn.get("tool_calls", []))


user_msg = st.chat_input("Ask a question about the data")
if user_msg:
    with st.chat_message("user"):
        st.markdown(user_msg)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            llm_history = [
                {"role": t["role"], "content": t["content"]}
                for t in st.session_state.chat_history
            ]
            try:
                result = run_agent(user_msg, llm_history, data)
                answer = result["answer"]
                tool_calls = result["tool_calls"]
                plot_spec = result.get("plot_spec")
            except Exception as e:
                answer = f"Error: {e}"
                tool_calls = []
                plot_spec = None

        st.markdown(answer or "_(no answer)_")
        tc_serialized = [
            {"name": tc.name, "arguments": tc.arguments, "result": tc.result}
            for tc in tool_calls
        ]
        _render_plot(plot_spec, tc_serialized, user_msg)
        _render_tool_calls(tc_serialized)

    st.session_state.chat_history.append({"role": "user", "content": user_msg})
    st.session_state.chat_history.append(
        {
            "role": "assistant",
            "content": answer,
            "tool_calls": tc_serialized,
            "plot_spec": plot_spec,
        }
    )
