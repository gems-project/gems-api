# Deploy GEMS API to Azure App Service (always-on, Databricks stays where it is)

**Scope:** This guide uses **Azure App Service** (Web App) with the **Linux + Python** runtime — not Azure Container Apps, AKS, or VM-only setups.

## Start here (do in this order)

We cannot log into your Azure account from here — you complete these in **Azure Portal** (and optionally your PC). Check off as you go:

1. **Create Web App** — Linux, Python 3.11+, **Basic B1** (or higher) if you want **Always On**.
2. **Startup command** — set to: `bash startup.sh` (after code is deployed; you can set it now).
3. **Application settings** — add every variable from the table in §4 (copy values from your local `API/.env`, not from git).
4. **Deploy the `API` folder** — `main.py` must live at the **site root** (see §5). Include `requirements.txt`, `startup.sh`, `.deployment`.
5. **Save** settings → **Restart** the Web App.
6. **Always On** — turn on under Configuration → General settings (paid tiers).
7. **Test** — `https://<your-app>.azurewebsites.net/docs` (§8).
8. If exports fail — check **Log stream** and Databricks **network / IP allow lists** (§7).

---

Your **gold data stays in Databricks** (Unity Catalog + Delta). The Azure app is only a **small Python service** that:

1. Receives **HTTPS** requests from users.
2. Checks **`X-API-Key`**.
3. Opens a **SQL connection** to your **Databricks SQL warehouse** (using the PAT you store in Azure config).
4. Runs **`SELECT`** on allowlisted tables and returns **CSV**.

Users **never** get your Databricks token. Azure runs **24/7** (with the right plan); your laptop can be off.

---

## 1. Prerequisites

- Azure subscription and permission to create an **App Service** (or ask your IT).
- This repo’s **`API`** folder (`main.py`, `requirements.txt`, optional `startup.sh`).
- Same values you already put in **`API/.env`** — you will paste them into Azure **Application settings** (not into git).

---

## 2. Create Azure App Service (Linux + Python)

1. Azure Portal → **Create a resource** → **Web App** (App Service).
2. **Publish**: Code. **Runtime stack**: Python **3.11** or **3.12** (match what you use locally if possible).
3. **Operating System**: **Linux** (recommended for this guide).
4. **Region**: choose one (e.g. same broad region as Databricks if you care about latency).
5. **Pricing plan**: at least **Basic B1** or higher if you need **Always On** (see below). Free tier may sleep and cold-start; not ideal for “always available.”
6. Finish **Review + create**.

---

## 3. Configure startup (so Azure can reach your app)

App Service must bind to **`0.0.0.0`** and the port Azure expects (often **`PORT`** env var, default **8000**).

**Option A — use `startup.sh` (this repo)**

In the portal: **Configuration** → **General settings** → **Startup Command**:

```bash
bash startup.sh
```

Ensure `startup.sh` is deployed with your code (same folder as `main.py`).

**Option B — one-line Gunicorn**

**Startup Command:**

```bash
gunicorn main:app --workers 2 --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

If the health check fails, try binding to `0.0.0.0:${PORT}` — some stacks set `PORT` automatically; see Azure diagnostics.

**If the portal has no “Startup command” field (common on Linux Python):** set it with **Azure CLI** or **Cloud Shell** (Bash):

```bash
az webapp config set --resource-group GEMS --name GEMS-API --startup-file "bash startup.sh"
az webapp config show --resource-group GEMS --name GEMS-API --query appCommandLine -o tsv
az webapp restart --resource-group GEMS --name GEMS-API
```

Replace `GEMS` / `GEMS-API` with your resource group and app name. Fallback startup file (use this if `bash startup.sh` fails — avoids CRLF issues on Windows):

`gunicorn main:app --workers 2 --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000`

**If Log stream shows `startup.sh: line N: set: -: invalid option`:** your `startup.sh` was likely saved with **Windows (CRLF)** line endings. Either save **`startup.sh` as UTF-8 with LF only** in the editor, or switch the Web App startup command to the **Gunicorn one-liner** above (no `bash startup.sh`).

---

## 4. Application settings (environment variables)

**Configuration** → **Application settings** → **New application setting** for each (names match your `.env`):

| Name | Value | Notes |
|------|--------|--------|
| `DATABRICKS_HOST` | `adb-....azuredatabricks.net` | No `https://` |
| `DATABRICKS_HTTP_PATH` | `/sql/1.0/warehouses/...` | Full path from warehouse connection details |
| `DATABRICKS_TOKEN` | `dapi-...` | PAT (prefer a **dedicated** token for this app, not your personal daily driver) |
| `GEMS_CATALOG` | `gems_catalog` | Adjust if yours differ |
| `GEMS_SCHEMA` | `gems_schema` | Adjust if yours differ |
| `ALLOWED_TABLES` | `goldtable1,goldtable2` | Comma-separated |
| `GEMS_API_KEY` | long random secret | What clients send as `X-API-Key` |
| `MAX_EXPORT_ROWS` | `100000` | Optional cap |

**Save** and restart the app.

**Do not** upload `API/.env` to git. Only paste secrets in the portal (or **Azure Key Vault** references later).

---

## 5. Deploy the code

**Important:** The deployed root must contain `main.py` at the **top level** (not inside a subfolder). Deploy the **contents** of this repo’s **`API`** folder.

Pick one:

- **VS Code** “Azure App Service” extension: right-click the **`API`** folder → **Deploy to Web App** (confirm it does not add an extra parent folder).
- **GitHub Actions** / **Azure DevOps**: set the job’s working directory to **`API`** before deploy.
- **Zip deploy (PowerShell):** from inside `API`, zip **files at the root of the zip**, not the folder itself:

```powershell
cd "...\data-entry-template\API"
# List only what the app needs — do NOT zip `.venv`, `__pycache__`, or `.env`
Compress-Archive -Path main.py,requirements.txt,startup.sh,.deployment,.env.example -DestinationPath ..\gems-api.zip -Force
```

(Add `README.md` / `DEPLOY_AZURE.md` if you want them on the server; **never** put `.env` in the zip.) Then in Portal: **Deployment Center** or **Advanced Tools (Kudu)** → upload and extract, or use Azure CLI `az webapp deployment source config-zip`.

The **`.deployment`** file in this folder sets `SCM_DO_BUILD_DURING_DEPLOYMENT=true` so Azure runs **`pip install -r requirements.txt`** on deploy.

After deploy, **Log stream** or **SSH** can confirm the build and Gunicorn start.

---

## 6. Always available

- **Configuration** → **General settings** → enable **Always On** (requires a paid tier that supports it).
- Otherwise the app may **idle** and wake on first request (slower first hit).

---

## 7. Networking: Azure → Databricks

- Usually **no code change**: outbound HTTPS from App Service to `*.azuredatabricks.net` works on the public internet.
- If your workspace uses **IP access lists** or **Private Link**, your **Azure outbound IPs** (or integration subnet) must be **allowed** on the Databricks side. If queries fail with timeouts or 403 from Databricks, work with your admin on **firewall / Private Endpoint** rules.

---

## 8. Test after deploy

1. Open `https://<your-app-name>.azurewebsites.net/docs`
2. `GET /health`
3. `GET /tables` with header **`X-API-Key`**
4. `GET /export/<table>.csv` with the same header

Share **`https://<your-app-name>.azurewebsites.net`** (and how to send the API key over **HTTPS** only) with trusted users — not your PAT.

---

## 9. Optional hardening (later)

- **Key Vault** references for `DATABRICKS_TOKEN` and `GEMS_API_KEY`.
- **Custom domain** + TLS.
- Separate **PAT per environment** (dev/staging/prod) and rotation policy.
